package usc.app.coinmarket.objetos;

public class Caratula_todo {
}
