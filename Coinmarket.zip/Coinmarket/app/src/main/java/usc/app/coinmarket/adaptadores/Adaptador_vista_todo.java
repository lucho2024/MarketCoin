package usc.app.coinmarket.adaptadores;

public class Adaptador_vista_todo {
}
